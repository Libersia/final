# Personal Expense Tracker System

A complete, offline personal finance management system built with HTML, CSS, JavaScript, Java (HTTP REST API + SQLite), and Python analytics.

---

## Quick Start (How to Launch)

### On Windows (Recommended)
Simply double-click:
```
run.bat
```
*(or `start_app.bat` / `start_backend.bat`)*

**What the launcher does automatically:**
1. Verifies that Java (JDK or JRE 17+) is installed.
2. Checks if the backend is already running on port 8080.
3. Automatically compiles or loads the Java backend.
4. Initializes the SQLite database (`database/expense_tracker.db`) without deleting existing user data.
5. Waits until the Java backend is active and healthy.
6. Automatically opens the application in your default web browser at `http://localhost:8080`.

### To Stop the Server (Windows)
When you are done using the application, double-click:
```
stop_server.bat
```
*(or close the "Personal Expense Tracker Server" console window).*

---

### On Linux Server (Ubuntu, Debian, CentOS, VPS, Cloud)
Make the shell scripts executable:
```bash
chmod +x run.sh start_backend.sh stop_server.sh
```

* **Run in foreground** (Live console logs, press `Ctrl+C` to cleanly stop):
  ```bash
  ./run.sh
  ```
* **Run in background (Hosting / Daemon mode)**:
  ```bash
  ./run.sh start
  ```
  *(Logs are saved to `server.log`, PID saved to `server.pid`)*
* **Check server health & status**:
  ```bash
  ./run.sh status
  ```
* **Stop the running server**:
  ```bash
  ./run.sh stop
  ```
  *(or `./stop_server.sh`)*
* **Restart the server**:
  ```bash
  ./run.sh restart
  ```

---

## System Requirements

### Java Requirement
* **Java Version**: **Java 17 or higher** (JDK or JRE).
* **Download (Free & Open Source)**:
  - [Eclipse Adoptium Temurin 17 (Recommended)](https://adoptium.net/temurin/releases/?version=17)
  - [Oracle JDK 17+](https://www.oracle.com/java/technologies/downloads/)
* **Installation Tip**:
  During installation on Windows, ensure the following installer options are enabled:
  - `Add to PATH`
  - `Set JAVA_HOME variable`

### Python (Optional)
* The Java backend includes a built-in pure Java financial analytics fallback.
* If Python 3.8+ is installed, optional advanced chart calculations will automatically leverage `python/reports.py`.

---

## Troubleshooting "Cannot connect to the Java server"

If you copy this folder to another computer and see:
> *"Cannot connect to the Java server. Please make sure the backend is running."*

Check the following:

1. **Did you launch via `run.bat`?**
   - Opening `login.html` directly in your browser as a file (`file://`) will not run the Java server. You must start the backend using `run.bat` or `start_app.bat`.
2. **Is Java 17+ installed on the computer?**
   - If Java is not installed, `run.bat` will display download instructions.
3. **Is port 8080 occupied by another application?**
   - Run `stop_server.bat` to clear port 8080, then run `run.bat` again.

---

## Data Preservation & Security

* **Database**: Stored locally in `database/expense_tracker.db`.
* **Accounts & History**: Existing user accounts, expenses, income records, and budget allocations are fully preserved and persistent across restarts.
* **Passwords**: Protected using PBKDF2 with unique cryptographic salts.
