#!/usr/bin/env bash
# Startup script for Personal Expense Tracker (delegates to run.sh)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$SCRIPT_DIR/run.sh" "$@"
