@echo off
setlocal enabledelayedexpansion

title Stop Personal Expense Tracker Server
cd /d "%~dp0"

echo ============================================================
echo      STOPPING PERSONAL EXPENSE TRACKER SERVER (PORT 8080)
echo ============================================================
echo.

powershell.exe -NoProfile -ExecutionPolicy Bypass -Command ^
    "$conns = Get-NetTCPConnection -LocalPort 8080 -ErrorAction SilentlyContinue; " ^
    "if ($conns) { " ^
    "    $pids = $conns | Select-Object -ExpandProperty OwningProcess -Unique; " ^
    "    foreach ($pidToKill in $pids) { " ^
    "        if ($pidToKill -gt 0) { " ^
    "            Write-Host ('[OK] Terminating backend process ID: ' + $pidToKill); " ^
    "            Stop-Process -Id $pidToKill -Force -ErrorAction SilentlyContinue; " ^
    "        } " ^
    "    }; " ^
    "    Write-Host '[OK] Personal Expense Tracker backend has been stopped.' -ForegroundColor Green " ^
    "} else { " ^
    "    Write-Host '[Info] No server process is currently running on port 8080.' -ForegroundColor Yellow " ^
    "}"

ping 127.0.0.1 -n 2 >nul
exit /b 0
