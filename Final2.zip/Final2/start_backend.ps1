# start_backend.ps1
# Startup script for Personal Expense Tracker Java Backend

$ErrorActionPreference = "Stop"

# Ensure working directory is always the project root
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (-not $ScriptDir) { $ScriptDir = $PSScriptRoot }
if (-not $ScriptDir) { $ScriptDir = (Get-Location).Path }
Set-Location $ScriptDir

Write-Host "=================================================="
Write-Host "      PERSONAL EXPENSE TRACKER - STARTING         "
Write-Host "=================================================="

# 1. Check if server is already running on port 8080
$isPortOpen = $false
try {
    $client = New-Object System.Net.Sockets.TcpClient
    $iar = $client.BeginConnect("127.0.0.1", 8080, $null, $null)
    $wait = $iar.AsyncWaitHandle.WaitOne(800, $false)
    if ($wait) {
        $client.EndConnect($iar)
        $client.Close()
        $isPortOpen = $true
    } else {
        $client.Close()
        $isPortOpen = $false
    }
} catch {
    $isPortOpen = $false
}

if ($isPortOpen) {
    # Verify if it is our Expense Tracker backend
    $isOurBackend = $false
    try {
        $healthReq = [System.Net.HttpWebRequest]::Create("http://localhost:8080/api/health")
        $healthReq.Timeout = 1500
        $healthRes = $healthReq.GetResponse()
        $healthRes.Close()
        $isOurBackend = $true
    } catch {
        if ($_.Exception.Response) {
            $_.Exception.Response.Close()
            $isOurBackend = $true
        } else {
            $isOurBackend = $false
        }
    }

    if ($isOurBackend) {
        Write-Host "[Start] Java backend is already running on http://localhost:8080."
        Write-Host "[Start] Opening frontend in your default browser..."
        Start-Process "http://localhost:8080"
        exit 0
    } else {
        Write-Error "[Start] Error: Port 8080 is in use by another application. Please free port 8080 before starting the server."
        exit 1
    }
}

# 2. Locate Java executable
$javaCmd = $null
if ($env:JAVA_HOME -and (Test-Path "$env:JAVA_HOME\bin\java.exe")) {
    $javaCmd = "$env:JAVA_HOME\bin\java.exe"
}

if (-not $javaCmd) {
    $cmd = Get-Command java -ErrorAction SilentlyContinue
    if ($cmd) { $javaCmd = $cmd.Source }
}

if (-not $javaCmd) {
    $searchRoots = @(
        "$env:ProgramFiles\Java",
        "$env:ProgramFiles\Eclipse Adoptium",
        "$env:ProgramFiles\BellSoft",
        "$env:ProgramFiles\Microsoft",
        "$env:ProgramFiles\Zulu",
        "${env:ProgramFiles(x86)}\Java",
        "$env:LOCALAPPDATA\Programs\Eclipse Adoptium",
        "$env:USERPROFILE\.jdks",
        "$env:USERPROFILE\.antigravity-ide",
        "$env:USERPROFILE\.p2",
        "$env:USERPROFILE\.vscode\extensions"
    )
    foreach ($root in $searchRoots) {
        if (Test-Path $root) {
            $found = (Get-ChildItem -Path $root -Filter "java.exe" -Recurse -Depth 5 -ErrorAction SilentlyContinue | Select-Object -First 1).FullName
            if ($found) {
                $javaCmd = $found
                break
            }
        }
    }
}

if (-not $javaCmd) {
    Write-Error "[Start] Error: Could not locate java.exe. Please install Java (JDK or JRE 17+) and ensure it is added to your PATH or JAVA_HOME."
    exit 1
}

Write-Host "[Start] Using Java at: $javaCmd"

# 3. Locate Javac executable
$javacCmd = $null
$siblingJavac = Join-Path (Split-Path $javaCmd) "javac.exe"
if (Test-Path $siblingJavac) {
    $javacCmd = $siblingJavac
}

if (-not $javacCmd -and $env:JAVA_HOME -and (Test-Path "$env:JAVA_HOME\bin\javac.exe")) {
    $javacCmd = "$env:JAVA_HOME\bin\javac.exe"
}

if (-not $javacCmd) {
    $cmd = Get-Command javac -ErrorAction SilentlyContinue
    if ($cmd) { $javacCmd = $cmd.Source }
}

if (-not $javacCmd) {
    foreach ($root in $searchRoots) {
        if (Test-Path $root) {
            $found = (Get-ChildItem -Path $root -Filter "javac.exe" -Recurse -Depth 5 -ErrorAction SilentlyContinue | Select-Object -First 1).FullName
            if ($found) {
                $javacCmd = $found
                break
            }
        }
    }
}

# 4. Compile Java source files
if ($javacCmd) {
    Write-Host "[Start] Compiling Java backend using $javacCmd..."
    & $javacCmd -cp "lib/*;java" java/*.java -d java
    if ($LASTEXITCODE -ne 0) {
        Write-Error "[Start] Java compilation failed! Please check your Java source files."
        exit 1
    }
    Write-Host "[Start] Compilation successful."
} else {
    if (Test-Path "java\Main.class") {
        Write-Host "[Start] Note: javac.exe not found (JRE environment detected), but precompiled class files exist. Running existing build..."
    } else {
        Write-Error "[Start] Error: javac.exe not found and no compiled class files exist. Please install a JDK to compile the project."
        exit 1
    }
}

# 5. Start Java Main server and launch browser
Write-Host "[Start] Starting Java server on port 8080..."
$serverProcess = Start-Process -FilePath $javaCmd -ArgumentList "-cp `"lib/*;java`" Main" -WorkingDirectory $ScriptDir -PassThru

# Wait for server to become ready
Write-Host "[Start] Waiting for server to become ready..."
$serverReady = $false
for ($i = 0; $i -lt 20; $i++) {
    Start-Sleep -Milliseconds 600
    try {
        $healthReq = [System.Net.HttpWebRequest]::Create("http://localhost:8080/api/health")
        $healthReq.Timeout = 1000
        $healthRes = $healthReq.GetResponse()
        $healthRes.Close()
        $serverReady = $true
        break
    } catch {
        # Retry
    }
}

if ($serverReady) {
    Write-Host ""
    Write-Host "=================================================="
    Write-Host "  PERSONAL EXPENSE TRACKER STARTED SUCCESSFULLY!  "
    Write-Host "=================================================="
    Write-Host "Access frontend at: http://localhost:8080"
    Write-Host "Opening in default browser..."
    Start-Process "http://localhost:8080"
} else {
    Write-Error "[Start] Server did not become ready within 15 seconds. Please inspect server logs or port 8080."
    exit 1
}
