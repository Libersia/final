#!/usr/bin/env bash
# ==============================================================================
# Personal Expense Tracker - Linux Server Launcher & Service Manager
# ==============================================================================
# Usage:
#   ./run.sh               # Run server in foreground (live logs, Ctrl+C to stop)
#   ./run.sh start         # Start server in background (daemon mode)
#   ./run.sh stop          # Stop running server
#   ./run.sh restart       # Restart server in background
#   ./run.sh status        # Check health and status of the server
#   ./run.sh compile       # Compile Java source code only
# ==============================================================================

# Ensure working directory is always the project root
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

PORT=8080
PID_FILE="$SCRIPT_DIR/server.pid"
LOG_FILE="$SCRIPT_DIR/server.log"

print_banner() {
    echo "=================================================="
    echo "      PERSONAL EXPENSE TRACKER - LINUX SERVER     "
    echo "=================================================="
}

# ------------------------------------------------------------------------------
# Helper: Detect Primary Network IP Address for Remote Access
# ------------------------------------------------------------------------------
get_server_ip() {
    local ip=""
    if command -v hostname >/dev/null 2>&1; then
        ip=$(hostname -I 2>/dev/null | awk '{print $1}')
    fi
    if [ -z "$ip" ] && command -v ip >/dev/null 2>&1; then
        ip=$(ip route get 1.1.1.1 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="src") print $(i+1)}')
    fi
    if [ -z "$ip" ]; then
        ip="<server-ip>"
    fi
    echo "$ip"
}

# ------------------------------------------------------------------------------
# Helper: Check if backend /api/health responds
# ------------------------------------------------------------------------------
check_health() {
    if command -v curl >/dev/null 2>&1; then
        curl -s -m 2 "http://127.0.0.1:${PORT}/api/health" 2>/dev/null | grep -q "ExpenseTrackerBackend"
        return $?
    elif command -v wget >/dev/null 2>&1; then
        wget -q -O - -T 2 "http://127.0.0.1:${PORT}/api/health" 2>/dev/null | grep -q "ExpenseTrackerBackend"
        return $?
    elif (exec 3<>/dev/tcp/127.0.0.1/${PORT}) 2>/dev/null; then
        exec 3>&-
        return 0
    fi
    return 1
}

# ------------------------------------------------------------------------------
# Helper: Check if port 8080 is listening
# ------------------------------------------------------------------------------
check_port_in_use() {
    if (exec 3<>/dev/tcp/127.0.0.1/${PORT}) 2>/dev/null; then
        exec 3>&-
        return 0
    fi
    if command -v ss >/dev/null 2>&1; then
        ss -tulpn 2>/dev/null | grep -q ":${PORT} " && return 0
    fi
    if command -v lsof >/dev/null 2>&1; then
        lsof -i ":${PORT}" >/dev/null 2>&1 && return 0
    fi
    if command -v netstat >/dev/null 2>&1; then
        netstat -tulpn 2>/dev/null | grep -q ":${PORT} " && return 0
    fi
    return 1
}

# ------------------------------------------------------------------------------
# Step 1: Locate Java Executable (Java 17+)
# ------------------------------------------------------------------------------
find_java() {
    JAVA_CMD=""

    if [ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/java" ]; then
        JAVA_CMD="$JAVA_HOME/bin/java"
    elif command -v java >/dev/null 2>&1; then
        JAVA_CMD="$(command -v java)"
    else
        local candidate_paths=(
            "/usr/lib/jvm/java-17-openjdk-amd64/bin/java"
            "/usr/lib/jvm/java-17-openjdk-arm64/bin/java"
            "/usr/lib/jvm/java-17-openjdk/bin/java"
            "/usr/lib/jvm/java-21-openjdk-amd64/bin/java"
            "/usr/lib/jvm/java-21-openjdk-arm64/bin/java"
            "/usr/lib/jvm/java-21-openjdk/bin/java"
            "/usr/lib/jvm/default-java/bin/java"
            "/opt/java/openjdk/bin/java"
            "/usr/java/latest/bin/java"
            "$HOME/.sdkman/candidates/java/current/bin/java"
        )
        for path in "${candidate_paths[@]}"; do
            if [ -x "$path" ]; then
                JAVA_CMD="$path"
                break
            fi
        done
    fi

    if [ -z "$JAVA_CMD" ]; then
        echo ""
        echo "============================================================"
        echo "  [ERROR] Java was not found on this Linux server!"
        echo "============================================================"
        echo "  The Personal Expense Tracker requires Java 17 or higher."
        echo ""
        echo "  To install Java 17 on Ubuntu/Debian:"
        echo "    sudo apt update && sudo apt install -y openjdk-17-jdk"
        echo ""
        echo "  To install Java 17 on RHEL / CentOS / Rocky / Fedora:"
        echo "    sudo dnf install -y java-17-openjdk-devel"
        echo ""
        echo "  To install Java 17 on Alpine Linux:"
        echo "    sudo apk add openjdk17"
        echo "============================================================"
        echo ""
        exit 1
    fi

    echo "[Start] Using Java at: $JAVA_CMD"
}

# ------------------------------------------------------------------------------
# Step 2: Locate Javac Compiler
# ------------------------------------------------------------------------------
find_javac() {
    JAVAC_CMD=""

    local sibling_javac
    sibling_javac="$(dirname "$JAVA_CMD")/javac"
    if [ -x "$sibling_javac" ]; then
        JAVAC_CMD="$sibling_javac"
    elif [ -n "$JAVA_HOME" ] && [ -x "$JAVA_HOME/bin/javac" ]; then
        JAVAC_CMD="$JAVA_HOME/bin/javac"
    elif command -v javac >/dev/null 2>&1; then
        JAVAC_CMD="$(command -v javac)"
    fi
}

# ------------------------------------------------------------------------------
# Step 3: Compile Java Backend
# ------------------------------------------------------------------------------
compile_backend() {
    if [ -n "$JAVAC_CMD" ]; then
        echo "[Start] Compiling Java backend using $JAVAC_CMD..."
        "$JAVAC_CMD" -cp "lib/*:java" java/*.java -d java
        local status=$?
        if [ $status -ne 0 ]; then
            echo "[ERROR] Java compilation failed (exit code $status)!"
            exit 1
        fi
        echo "[Start] Compilation successful."
    else
        if [ -f "java/Main.class" ]; then
            echo "[Start] Note: javac not found (JRE environment), using existing precompiled classes..."
        else
            echo ""
            echo "============================================================"
            echo "  [ERROR] javac compiler not found and no classes compiled!"
            echo "============================================================"
            echo "  Please install a full JDK 17 (e.g. openjdk-17-jdk):"
            echo "    sudo apt install -y openjdk-17-jdk"
            echo "============================================================"
            echo ""
            exit 1
        fi
    fi
}

# ------------------------------------------------------------------------------
# Launch in Foreground (default: ./run.sh)
# ------------------------------------------------------------------------------
run_foreground() {
    print_banner

    if check_health; then
        echo "[Info] Java backend is already running on http://localhost:${PORT}."
        status_server
        exit 0
    fi

    if check_port_in_use; then
        echo "[ERROR] Port ${PORT} is occupied by another process!"
        echo "[ERROR] Please free port ${PORT} or run: ./run.sh stop"
        exit 1
    fi

    find_java
    find_javac
    compile_backend

    echo "[Start] Launching Java server on port ${PORT} (foreground mode)..."
    echo "[Start] Press Ctrl+C at any time to gracefully stop the server."
    echo ""

    # Ensure clean shutdown on SIGINT / SIGTERM / EXIT
    cleanup() {
        echo ""
        echo "[Server] Shutting down Java backend..."
        if [ -n "$SERVER_PID" ] && kill -0 "$SERVER_PID" 2>/dev/null; then
            kill -TERM "$SERVER_PID" 2>/dev/null || true
            wait "$SERVER_PID" 2>/dev/null || true
        fi
        rm -f "$PID_FILE"
        echo "[Server] Stopped."
    }
    trap cleanup INT TERM

    "$JAVA_CMD" -cp "lib/*:java" Main &
    SERVER_PID=$!
    echo "$SERVER_PID" > "$PID_FILE"

    # Async health poll and announcement
    (
        local ready=0
        for i in $(seq 1 25); do
            sleep 0.5
            if check_health; then
                ready=1
                break
            fi
            if ! kill -0 "$SERVER_PID" 2>/dev/null; then
                break
            fi
        done

        if [ "$ready" -eq 1 ]; then
            local ip
            ip=$(get_server_ip)
            echo ""
            echo "=================================================="
            echo "  PERSONAL EXPENSE TRACKER STARTED SUCCESSFULLY!  "
            echo "=================================================="
            echo "  Local URL:    http://localhost:${PORT}"
            echo "  Network URL:  http://${ip}:${PORT}"
            echo "  Database:     database/expense_tracker.db"
            echo "=================================================="
            echo ""
            # If a desktop GUI environment is detected, optionally open browser
            if [ -n "$DISPLAY" ] || [ -n "$WAYLAND_DISPLAY" ]; then
                if command -v xdg-open >/dev/null 2>&1; then
                    xdg-open "http://localhost:${PORT}" >/dev/null 2>&1 || true
                elif command -v open >/dev/null 2>&1; then
                    open "http://localhost:${PORT}" >/dev/null 2>&1 || true
                fi
            fi
        fi
    ) &

    wait "$SERVER_PID"
    rm -f "$PID_FILE"
}

# ------------------------------------------------------------------------------
# Launch in Background / Daemon Mode (./run.sh start)
# ------------------------------------------------------------------------------
start_daemon() {
    print_banner

    if check_health; then
        echo "[Info] Java backend is already running on port ${PORT}."
        status_server
        return 0
    fi

    if check_port_in_use; then
        echo "[ERROR] Port ${PORT} is occupied by another process!"
        echo "[ERROR] Please free port ${PORT} or run: ./run.sh stop"
        return 1
    fi

    find_java
    find_javac
    compile_backend

    echo "[Start] Starting Java server in background (daemon mode)..."
    nohup "$JAVA_CMD" -cp "lib/*:java" Main > "$LOG_FILE" 2>&1 &
    SERVER_PID=$!
    echo "$SERVER_PID" > "$PID_FILE"

    echo "[Start] Waiting for server to become ready..."
    local ready=0
    for i in $(seq 1 25); do
        sleep 0.5
        if check_health; then
            ready=1
            break
        fi
        if ! kill -0 "$SERVER_PID" 2>/dev/null; then
            echo "[ERROR] Java server process terminated unexpectedly. Recent logs:"
            tail -n 25 "$LOG_FILE" 2>/dev/null
            rm -f "$PID_FILE"
            return 1
        fi
    done

    if [ "$ready" -eq 1 ]; then
        local ip
        ip=$(get_server_ip)
        echo ""
        echo "=================================================="
        echo "  PERSONAL EXPENSE TRACKER STARTED SUCCESSFULLY!  "
        echo "=================================================="
        echo "  Local URL:     http://localhost:${PORT}"
        echo "  Network URL:   http://${ip}:${PORT}"
        echo "  Process ID:    $SERVER_PID (saved in server.pid)"
        echo "  Log File:      $LOG_FILE"
        echo ""
        echo "  Commands:"
        echo "    View logs:   tail -f $LOG_FILE"
        echo "    Stop server: ./run.sh stop"
        echo "    Status:      ./run.sh status"
        echo "=================================================="
        echo ""
        return 0
    else
        echo "[ERROR] Server did not respond within 12 seconds."
        echo "[ERROR] Check $LOG_FILE for details. Recent logs:"
        tail -n 25 "$LOG_FILE" 2>/dev/null
        return 1
    fi
}

# ------------------------------------------------------------------------------
# Stop Running Server (./run.sh stop)
# ------------------------------------------------------------------------------
stop_server() {
    echo "=================================================="
    echo "   STOPPING PERSONAL EXPENSE TRACKER BACKEND      "
    echo "=================================================="

    local killed=0

    # 1. Check PID file
    if [ -f "$PID_FILE" ]; then
        local pid
        pid=$(cat "$PID_FILE" 2>/dev/null)
        if [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null; then
            echo "[Stop] Terminating backend PID $pid..."
            kill -TERM "$pid" 2>/dev/null || true
            for i in $(seq 1 10); do
                if ! kill -0 "$pid" 2>/dev/null; then
                    break
                fi
                sleep 0.3
            done
            if kill -0 "$pid" 2>/dev/null; then
                echo "[Stop] Process did not terminate; sending SIGKILL..."
                kill -9 "$pid" 2>/dev/null || true
            fi
            killed=1
        fi
        rm -f "$PID_FILE"
    fi

    # 2. Check any remaining process bound to port 8080
    if command -v fuser >/dev/null 2>&1; then
        if fuser -n tcp "${PORT}" >/dev/null 2>&1; then
            echo "[Stop] Clearing remaining process on port ${PORT}..."
            fuser -k -n tcp "${PORT}" >/dev/null 2>&1 || true
            killed=1
        fi
    elif command -v lsof >/dev/null 2>&1; then
        local pids
        pids=$(lsof -t -i ":${PORT}" 2>/dev/null)
        if [ -n "$pids" ]; then
            echo "[Stop] Killing processes listening on port ${PORT}: $pids"
            kill -9 $pids 2>/dev/null || true
            killed=1
        fi
    fi

    if [ "$killed" -eq 1 ]; then
        echo "[OK] Personal Expense Tracker backend has been stopped."
    else
        echo "[Info] No active server process was found running on port ${PORT}."
    fi
}

# ------------------------------------------------------------------------------
# Check Server Status (./run.sh status)
# ------------------------------------------------------------------------------
status_server() {
    echo "=================================================="
    echo "   PERSONAL EXPENSE TRACKER - SERVER STATUS       "
    echo "=================================================="

    if check_health; then
        local pid="unknown"
        if [ -f "$PID_FILE" ]; then
            pid=$(cat "$PID_FILE" 2>/dev/null)
        fi
        local ip
        ip=$(get_server_ip)
        echo "  Status:      RUNNING (HEALTHY)"
        echo "  Port:        ${PORT}"
        echo "  Process ID:  ${pid}"
        echo "  Local URL:   http://localhost:${PORT}"
        echo "  Network URL: http://${ip}:${PORT}"
        echo "=================================================="
        return 0
    elif check_port_in_use; then
        echo "  Status:      PORT CONFLICT"
        echo "  Port ${PORT} is occupied, but health check failed."
        echo "=================================================="
        return 1
    else
        echo "  Status:      STOPPED (Not running)"
        echo "=================================================="
        return 3
    fi
}

# ------------------------------------------------------------------------------
# Help message
# ------------------------------------------------------------------------------
print_usage() {
    echo "Usage: ./run.sh [command]"
    echo ""
    echo "Commands:"
    echo "  (none)      Start server in foreground (default, live logs)"
    echo "  start       Start server in background (daemon mode with logs)"
    echo "  stop        Stop running server"
    echo "  restart     Restart background server"
    echo "  status      Check current server status and URL"
    echo "  compile     Compile Java source files without running"
    echo "  help        Display this help message"
}

# ------------------------------------------------------------------------------
# CLI Dispatcher
# ------------------------------------------------------------------------------
case "${1:-}" in
    start|--daemon|-d)
        start_daemon
        ;;
    stop)
        stop_server
        ;;
    restart)
        stop_server
        sleep 1
        start_daemon
        ;;
    status)
        status_server
        ;;
    compile)
        find_java
        find_javac
        compile_backend
        ;;
    run|foreground|-f)
        run_foreground
        ;;
    help|--help|-h)
        print_usage
        ;;
    "")
        run_foreground
        ;;
    *)
        echo "Unknown option: $1"
        print_usage
        exit 1
        ;;
esac
