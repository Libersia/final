#!/usr/bin/env bash
# Stop script for Personal Expense Tracker (delegates to run.sh stop)
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec "$SCRIPT_DIR/run.sh" stop "$@"
