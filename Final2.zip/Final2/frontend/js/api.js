/**
 * api.js - Centralized API Configuration and Client
 * Provides consistent frontend-to-backend communication across all pages,
 * whether loaded via http://localhost:8080 or directly from file://.
 */
(function(window) {
    'use strict';

    const API_PORT = 8080;
    const DEFAULT_LOCAL_BASE = `http://localhost:${API_PORT}/api`;

    function getBaseUrl() {
        const customBase = localStorage.getItem('api_base');
        if (customBase && customBase.trim()) {
            return customBase.trim().replace(/\/+$/, '');
        }

        const protocol = window.location.protocol;
        if (protocol === 'http:' || protocol === 'https:') {
            // When served via HTTP(S), always use current origin's /api endpoint
            return `${window.location.origin}/api`;
        }

        // When opened directly as a local file (file://), target the local Java server
        return DEFAULT_LOCAL_BASE;
    }

    function getUrl(endpoint) {
        if (!endpoint) endpoint = '';
        if (endpoint.startsWith('http://') || endpoint.startsWith('https://')) {
            return endpoint;
        }
        const base = getBaseUrl();
        const cleanPath = endpoint.startsWith('/') ? endpoint : '/' + endpoint;
        return `${base}${cleanPath}`;
    }

    /**
     * Checks if the Java backend is active and responding on the health check endpoint.
     */
    async function checkHealth(timeoutMs = 2500) {
        const primaryHealthUrl = getUrl('/health');
        const urlsToTry = [primaryHealthUrl];

        // If running from file://, also try 127.0.0.1 if primary is localhost (or vice versa)
        if (window.location.protocol === 'file:') {
            if (primaryHealthUrl.includes('localhost:8080')) {
                urlsToTry.push(primaryHealthUrl.replace('localhost:8080', '127.0.0.1:8080'));
            } else if (primaryHealthUrl.includes('127.0.0.1:8080')) {
                urlsToTry.push(primaryHealthUrl.replace('127.0.0.1:8080', 'localhost:8080'));
            }
        }

        for (const healthUrl of urlsToTry) {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

            try {
                const res = await fetch(healthUrl, {
                    method: 'GET',
                    signal: controller.signal
                });
                clearTimeout(timeoutId);
                if (res.ok) {
                    const data = await res.json().catch(() => ({}));
                    return { ok: true, status: res.status, data, endpoint: healthUrl };
                }
            } catch (err) {
                clearTimeout(timeoutId);
            }
        }

        return { ok: false, message: 'Java backend server is not running or unreachable on port 8080.' };
    }

    /**
     * Unified fetch wrapper that distinguishes error categories:
     * - Java backend not running
     * - Incorrect API address or port
     * - Server internal / startup failure (500)
     * - Invalid credentials (401)
     * - Database errors
     */
    async function request(endpoint, options = {}) {
        let url = getUrl(endpoint);
        const headers = Object.assign({}, options.headers || {});

        // Attach auth token if available
        const token = localStorage.getItem('auth_token');
        if (token && !headers['Authorization']) {
            headers['Authorization'] = `Bearer ${token}`;
        }

        // Default Content-Type to JSON if body is provided and not FormData
        if (options.body && !(options.body instanceof FormData) && !headers['Content-Type']) {
            headers['Content-Type'] = 'application/json';
        }

        const fetchOptions = Object.assign({}, options, { headers });

        let response;
        try {
            response = await fetch(url, fetchOptions);
        } catch (networkErr) {
            // When opened directly as a file://, try fallback between localhost and 127.0.0.1
            if (window.location.protocol === 'file:') {
                let altUrl = null;
                if (url.includes('localhost:8080')) {
                    altUrl = url.replace('localhost:8080', '127.0.0.1:8080');
                } else if (url.includes('127.0.0.1:8080')) {
                    altUrl = url.replace('127.0.0.1:8080', 'localhost:8080');
                }

                if (altUrl) {
                    try {
                        response = await fetch(altUrl, fetchOptions);
                    } catch (altErr) {
                        // Both failed
                    }
                }
            }

            if (!response) {
                const base = getBaseUrl();
                let userMessage;
                const isLocal = base.includes('localhost') || base.includes('127.0.0.1');

                if (isLocal) {
                    userMessage = 'Cannot connect to the Java server. Please make sure the backend is running via run.bat or start_backend.bat.';
                } else {
                    userMessage = `Cannot reach API at ${base}. Please verify the server address and port.`;
                }

                const error = new Error(userMessage);
                error.isConnectionError = true;
                error.originalError = networkErr;
                error.userMessage = userMessage;
                throw error;
            }
        }

        // Parse JSON response safely
        let data = null;
        const text = await response.text();
        if (text && text.trim()) {
            try {
                data = JSON.parse(text);
            } catch (jsonErr) {
                data = { rawText: text };
            }
        } else {
            data = {};
        }

        if (!response.ok) {
            let userMessage = (data && data.message) ? data.message : '';

            const isAuthEndpoint = endpoint.includes('/login') || endpoint.includes('/signup');

            if (response.status === 401) {
                if (isAuthEndpoint) {
                    userMessage = userMessage || 'Incorrect username or password.';
                } else {
                    userMessage = userMessage || 'Session expired. Please log in again.';
                    // Automatically redirect to login for protected pages
                    clearSession();
                    if (!window.location.pathname.endsWith('login.html') && !window.location.pathname.endsWith('signup.html')) {
                        window.location.href = 'login.html';
                    }
                }
            } else if (response.status === 404) {
                userMessage = userMessage || 'API endpoint not found (HTTP 404).';
            } else if (response.status >= 500) {
                if (userMessage.toLowerCase().includes('database') || userMessage.toLowerCase().includes('sql')) {
                    userMessage = `Database error: ${userMessage}`;
                } else {
                    userMessage = userMessage ? `Server error: ${userMessage}` : 'Java server encountered an internal error.';
                }
            } else {
                userMessage = userMessage || `Request failed (HTTP ${response.status}).`;
            }

            const error = new Error(userMessage);
            error.status = response.status;
            error.data = data;
            error.userMessage = userMessage;
            throw error;
        }

        return data;
    }

    function getToken() {
        return localStorage.getItem('auth_token');
    }

    function getUsername() {
        return localStorage.getItem('username');
    }

    function setSession(token, username) {
        if (token) localStorage.setItem('auth_token', token);
        if (username) localStorage.setItem('username', username);
    }

    function clearSession() {
        localStorage.removeItem('auth_token');
        localStorage.removeItem('username');
    }

    async function logout() {
        try {
            await request('/logout', { method: 'POST' });
        } catch (e) {
            // Ignore logout network errors on shutdown
        }
        clearSession();
        window.location.href = 'login.html';
    }

    function formatCurrency(amount) {
        const num = Number(amount || 0);
        return '₱' + num.toLocaleString('en-PH', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
    }

    function escapeHtml(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    // Expose API namespace globally
    window.API = {
        getBaseUrl,
        getUrl,
        checkHealth,
        request,
        getToken,
        getUsername,
        setSession,
        clearSession,
        logout,
        formatCurrency,
        escapeHtml
    };

})(window);
