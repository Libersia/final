@echo off
setlocal enabledelayedexpansion

title Personal Expense Tracker Launcher

:: Ensure working directory is the project root
cd /d "%~dp0"

echo ============================================================
echo         PERSONAL EXPENSE TRACKER - LAUNCHER
echo ============================================================
echo.

:: 1. Check if backend is ALREADY running on port 8080
call :verify_server_health
if "!SERVER_HEALTHY!"=="1" (
    echo [OK] Java backend is already running on http://localhost:8080.
    echo [OK] Opening frontend in your default browser...
    start http://localhost:8080
    ping 127.0.0.1 -n 2 >nul
    exit /b 0
)

:: 2. Locate Java executable (java.exe)
set "JAVA_CMD="

where java.exe >nul 2>&1
if %ERRORLEVEL% equ 0 (
    set "JAVA_CMD=java"
    goto :found_java
)

if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\java.exe" (
        set "JAVA_CMD=%JAVA_HOME%\bin\java.exe"
        goto :found_java
    )
)

for /d %%D in (
    "%ProgramFiles%\Eclipse Adoptium\jdk-17*"
    "%ProgramFiles%\Java\jdk-17*"
    "%ProgramFiles%\Java\jre-17*"
    "%ProgramFiles%\Microsoft\jdk-17*"
    "%ProgramFiles%\BellSoft\LibericaJDK-17*"
    "%ProgramFiles%\Zulu\zulu-17*"
    "%LOCALAPPDATA%\Programs\Eclipse Adoptium\jdk-17*"
    "%USERPROFILE%\.jdks\jdk-17*"
    "%ProgramFiles%\Eclipse Adoptium\jdk-*"
    "%ProgramFiles%\Java\jdk-*"
    "%ProgramFiles%\Java\jre-*"
    "%ProgramFiles(x86)%\Java\jdk-*"
    "%ProgramFiles(x86)%\Java\jre-*"
) do (
    if exist "%%D\bin\java.exe" (
        set "JAVA_CMD=%%D\bin\java.exe"
        goto :found_java
    )
)

:: Java not found
echo.
echo ============================================================
echo  [ERROR] Java was not found on this computer!
echo ============================================================
echo  The Personal Expense Tracker requires Java 17 or higher.
echo.
echo  HOW TO INSTALL JAVA:
echo  1. Download Eclipse Temurin JDK 17 (Recommended, Free):
echo     https://adoptium.net/temurin/releases/?version=17
echo.
echo  2. Run the downloaded installer.
echo     IMPORTANT: When prompted for features, make sure to enable:
echo       - "Add to PATH"
echo       - "Set JAVA_HOME variable"
echo.
echo  3. After installation completes, double-click run.bat again!
echo ============================================================
echo.
pause
exit /b 1

:found_java
echo [Start] Found Java at: %JAVA_CMD%

:: 3. Locate Javac executable
set "JAVAC_CMD="
where javac.exe >nul 2>&1
if %ERRORLEVEL% equ 0 (
    set "JAVAC_CMD=javac"
    goto :compile_code
)

if defined JAVA_HOME (
    if exist "%JAVA_HOME%\bin\javac.exe" (
        set "JAVAC_CMD=%JAVA_HOME%\bin\javac.exe"
        goto :compile_code
    )
)

:compile_code
if not defined JAVAC_CMD goto :check_precompiled

echo [Start] Compiling Java backend using %JAVAC_CMD%...
"%JAVAC_CMD%" -cp "lib/*;java" java\*.java -d java
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Java compilation failed! Please verify java source files.
    pause
    exit /b 1
)
echo [Start] Compilation successful.
goto :launch_server

:check_precompiled
if exist "java\Main.class" (
    echo [Start] JRE environment detected (javac not found). Using precompiled classes...
    goto :launch_server
)

echo.
echo ============================================================
echo  [ERROR] javac.exe was not found and java\Main.class is missing!
echo  Please install JDK 17+ to build the project.
echo ============================================================
pause
exit /b 1

:launch_server
echo [Start] Starting Java server on port 8080...
start "Personal Expense Tracker Server" "%JAVA_CMD%" -cp "lib/*;java" Main

echo [Start] Waiting for server to initialize...
set "SERVER_READY=0"
for /l %%I in (1,1,20) do (
    if "!SERVER_READY!"=="0" (
        call :verify_server_health
        if "!SERVER_HEALTHY!"=="1" (
            set "SERVER_READY=1"
        ) else (
            ping 127.0.0.1 -n 2 >nul
        )
    )
)

if "!SERVER_READY!"=="1" (
    echo.
    echo ============================================================
    echo   PERSONAL EXPENSE TRACKER IS NOW RUNNING!
    echo ============================================================
    echo   URL      : http://localhost:8080
    echo   Database : database\expense_tracker.db (active ^& preserved)
    echo.
    echo   The server window "Personal Expense Tracker Server" must
    echo   remain open while using the application.
    echo   To stop the server, close that window or run stop_server.bat.
    echo ============================================================
    echo.
    echo [OK] Opening frontend in your default browser...
    start http://localhost:8080
    ping 127.0.0.1 -n 3 >nul
    exit /b 0
) else (
    echo.
    echo ============================================================
    echo  [ERROR] The server did not respond within 20 seconds!
    echo  Please check the "Personal Expense Tracker Server" window
    echo  to see any startup error messages or port conflicts.
    echo ============================================================
    echo.
    pause
    exit /b 1
)

:: Subroutine: Check if server health endpoint responds
:verify_server_health
set "SERVER_HEALTHY=0"
where curl.exe >nul 2>&1
if %ERRORLEVEL% equ 0 (
    curl.exe -s -m 1 http://localhost:8080/api/health 2>nul | findstr /i "ExpenseTrackerBackend" >nul 2>&1
    if !ERRORLEVEL! equ 0 set "SERVER_HEALTHY=1"
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "try { $res = (Invoke-WebRequest -Uri 'http://localhost:8080/api/health' -TimeoutSec 1 -UseBasicParsing).Content; if ($res -like '*ExpenseTrackerBackend*') { exit 0 } else { exit 1 } } catch { exit 1 }" >nul 2>&1
    if !ERRORLEVEL! equ 0 set "SERVER_HEALTHY=1"
)
exit /b 0
