import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * Database.java
 * SQLite database initialization, connection pooling, and schema migration.
 */
public class Database {
    private static String dbDir = "database";
    private static String dbFile = "database/expense_tracker.db";
    private static String dbUrl = "jdbc:sqlite:" + dbFile;

    static {
        try {
            // Load SQLite JDBC Driver
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException e) {
            System.err.println("Failed to load SQLite JDBC Driver: " + e.getMessage());
        }
        resolveDbLocation();
    }

    private static void resolveDbLocation() {
        File f1 = new File("database", "expense_tracker.db");
        if (f1.exists()) {
            dbDir = f1.getParentFile().getPath();
            dbFile = f1.getPath();
            dbUrl = "jdbc:sqlite:" + f1.getAbsolutePath();
            return;
        }
        File f2 = new File("../database", "expense_tracker.db");
        if (f2.exists()) {
            dbDir = f2.getParentFile().getPath();
            dbFile = f2.getPath();
            dbUrl = "jdbc:sqlite:" + f2.getAbsolutePath();
            return;
        }
        File dir = new File("database");
        if (!dir.exists()) {
            File parentDir = new File("../database");
            if (parentDir.exists()) {
                dbDir = parentDir.getPath();
                dbFile = new File(parentDir, "expense_tracker.db").getPath();
                dbUrl = "jdbc:sqlite:" + new File(parentDir, "expense_tracker.db").getAbsolutePath();
                return;
            }
            dir.mkdirs();
        }
        dbDir = dir.getPath();
        dbFile = new File(dir, "expense_tracker.db").getPath();
        dbUrl = "jdbc:sqlite:" + new File(dir, "expense_tracker.db").getAbsolutePath();
    }

    /**
     * Initializes the database directory and tables if they do not exist.
     */
    public static void initialize() {
        resolveDbLocation();
        File dir = new File(dbDir);
        if (!dir.exists()) {
            dir.mkdirs();
        }

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {

            // Enable foreign keys
            stmt.execute("PRAGMA foreign_keys = ON;");

            // Users Table
            String createUsersTable = """
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password_hash TEXT NOT NULL,
                    created_at TEXT NOT NULL
                );
            """;
            stmt.execute(createUsersTable);

            // Expenses Table
            String createExpensesTable = """
                CREATE TABLE IF NOT EXISTS expenses (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    amount REAL NOT NULL,
                    description TEXT NOT NULL,
                    category TEXT NOT NULL,
                    payment_method TEXT NOT NULL,
                    date TEXT NOT NULL,
                    notes TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
                );
            """;
            stmt.execute(createExpensesTable);

            // Income Table
            String createIncomeTable = """
                CREATE TABLE IF NOT EXISTS income (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    amount REAL NOT NULL,
                    source TEXT NOT NULL,
                    category TEXT NOT NULL,
                    date TEXT NOT NULL,
                    notes TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
                );
            """;
            stmt.execute(createIncomeTable);

            // Budgets Table
            String createBudgetsTable = """
                CREATE TABLE IF NOT EXISTS budgets (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER NOT NULL,
                    category TEXT NOT NULL,
                    amount REAL NOT NULL,
                    month INTEGER NOT NULL,
                    year INTEGER NOT NULL,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
                );
            """;
            stmt.execute(createBudgetsTable);

            System.out.println("[Database] Initialization complete. Database ready at: " + dbFile);

        } catch (SQLException e) {
            System.err.println("[Database] Initialization error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    /**
     * Obtains a Connection to SQLite.
     * Always configures foreign_keys = ON.
     */
    public static Connection getConnection() throws SQLException {
        if (dbUrl == null) {
            resolveDbLocation();
        }
        Connection conn = DriverManager.getConnection(dbUrl);
        try (Statement stmt = conn.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON;");
        }
        return conn;
    }
}
